import os, sys

try:
	codioPort = sys.argv[1]
except IndexError:
	codioPort = input("Enter the codio connect port: ")

cmd = "echo y | plink.exe -ssh codio@forwarding.codio.co.uk -P {} -i codio.ppk".format(codioPort)
for i in range(1234,1251):
	cmd += " -L {0}:localhost:{0}".format(i)

print(cmd)
print()
os.system(cmd)
